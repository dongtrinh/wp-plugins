== Paid Member Subscriptions - Invoices Add-On ==

Contributors: cozmoslabs, Adrian Spiac
Author URL: https://cozmoslabs.com/
Donate link: https://www.cozmoslabs.com/
Tags: invoice, invoices, member invoices, membership invoice, subscription invoice, paid member subscriptions
Requires at least: 3.1
Tested up to: 5.3
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows both the site admin and customer to download a PDF invoice for their subscription purchase.


== Description ==

Paid Member Subscriptions - Invoices Add-on

Gives access to downloadable PDF invoices for both admins and customers.


== Installation ==

1. Upload and install the zip file via the built in WordPress plugin installer.
2. Activate the plugin from the "Plugins" admin panel using the "Activate" link.
