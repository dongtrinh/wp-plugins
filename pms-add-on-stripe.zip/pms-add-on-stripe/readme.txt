=== Paid Member Subscriptions - Stripe Payment Gateway Add-On ===
Contributors: cozmoslabs, iova.mihai
Donate link: https://www.cozmoslabs.com/wordpress-paid-member-subscriptions/
Tags: membership, paid membership, membership plan, stripe
Requires at least: 3.1
Tested up to: 5.4
Stable tag: 1.3.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Accept credit and debit card payments through Stripe

= Website =

https://www.cozmoslabs.com/wordpress-paid-member-subscriptions/

== Installation ==

1. Upload the pms-add-on-stripe folder to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Create a new page and use one of the shortcodes available. Publish the page and you're done!
