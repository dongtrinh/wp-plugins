== Paid Member Subscriptions - Discount Codes Add-On ==

Contributors: cozmoslabs, Adrian Spiac
Author URL: https://cozmoslabs.com/
Donate link: https://www.cozmoslabs.com/
Tags: discount, discount codes, membership, subscription discounts, paid member subscriptions
Requires at least: 3.1
Tested up to: 5.3
Stable tag: 1.3.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin adds a subpage where you can create discount codes for Paid Member Subscriptions.


== Description ==

Paid Member Subscriptions - Discount Codes

Easily create discount codes for your members subscriptions.


== Installation ==

1. Upload and install the zip file via the built in WordPress plugin installer.
2. Activate the plugin from the "Plugins" admin panel using the "Activate" link.
