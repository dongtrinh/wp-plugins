=== Paid Member Subscriptions - Email Reminders Add-On ===
Contributors: cozmoslabs, adispiac, iova.mihai
Donate link: https://www.cozmoslabs.com/wordpress-paid-member-subscriptions/
Tags: membership, paid membership, membership plan, email, email reminder
Requires at least: 3.1
Tested up to: 5.2.3
Stable tag: 1.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Send member subscription custom email reminders to members and administrators.

= Website =

https://www.cozmoslabs.com/wordpress-paid-member-subscriptions/

== Installation ==

1. Upload the paid-member-subscriptions folder to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Create a new page and use one of the shortcodes available. Publish the page and you're done!


== Changelog ==

= 1.1.2 =
* Fix issue where the cron events were registered twice.

= 1.0.0 =
* Initial release.
