=== Paid Member Subscriptions - Multiple Subscriptions per User Add-On ===
Contributors: cozmoslabs, iova.mihai
Donate link: http://www.cozmoslabs.com/wordpress-paid-member-subscriptions/
Tags: membership, paid membership, membership plan, subscription
Requires at least: 3.1
Tested up to: 5.4
Stable tag: 1.1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Setup multiple subscription level groups and allow members to sign up for more than one subscription plan (one per group).

= Website =

http://www.cozmoslabs.com/wordpress-paid-member-subscriptions/

== Installation ==

1. Upload the pms-add-on-multiple-subscriptions-per-user folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create a new page and use one of the shortcodes available. Publish the page and you're done!
