=== Paid Members Subscriptions - Global Content Restriction ===

Contributors: cozmoslabs, Madalin Ungureanu
Donate link: http://www.cozmoslabs.com/
Tags:
Requires at least: 3.1
Tested up to: 5.3
Stable tag: 1.0.8
Requires Paid Members Subscriptions Plugin
